package com.example.orderservice.model;

import java.util.List;

public class OrderRequest {

    private String customerName;
    private List<Item> items;

    // Getters and setters
}